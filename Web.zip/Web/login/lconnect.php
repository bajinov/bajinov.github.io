<?php
$secret="";
$uname= $_POST['Username'];
$pass= $_POST['Password'];

$conn = new mysqli('sql306.infinityfree.com', 'if0_35681883', 'MJN7pFUfAP', 'if0_35681883_users');
if ($conn->connect_error)
{
    die('Connection failed : '.$conn->connect_error);
}
else
{
    if($uname === 'Bajino' && $pass === 'Up')
    {
        session_start();
        $_SESSION['uname']=$uname;
        header("location:Files/main.php");
    }
    else if($uname === 'Bajino' && $pass === 'Down')
    { 
        session_start();
        $_SESSION['uname']=$uname;
        header("location:Files/Download.php");

    }
    $stmt = $conn->prepare("Select * from userdata where UserName =? ");
    $stmt->bind_param("s", $uname);
    $stmt->execute();
    $res=$stmt->get_result();
    if($res->num_rows > 0)
    {
         $data=$res->fetch_assoc();
         if($pass === $data['Pass'])
         {
            session_start();
            $_SESSION['uname']=$uname;
            header("location:Files/download1.php");
         }
         else
         {
            echo "Invalid Credentials";
         }
    }
    else
    {
        echo"Invalid credentials";
    }
    $stmt->close();
    $conn->close();
}
?>