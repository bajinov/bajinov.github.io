<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
session_start();
if (isset($_SESSION['uname'])) {
    $username = $_SESSION['uname'];
} else {
    header("location:/htdocs-OG/login/login.html ");
    exit();
}

$conn = new mysqli('sql306.infinityfree.com', 'if0_35681883', 'MJN7pFUfAP', 'if0_35681883_users');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['delete'])) {
    $filenameToDelete = $_POST['delete'];

    $filePathToDelete = "Uploaded/" . $filenameToDelete;
    if (file_exists($filePathToDelete)) {
        unlink($filePathToDelete);
    } else {
        echo "File not found: " . $filenameToDelete;
    }

    $sqlDelete = "DELETE FROM files WHERE filename = '$filenameToDelete'";
    if ($conn->query($sqlDelete) === TRUE) {
        echo "File deleted successfully.";
    } else {
        echo "Error deleting file: " . $conn->error;
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

$sql = "SELECT * FROM files";
$result = $conn->query($sql);
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Download PDF</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            text-align: center;
        }

        table {
            margin-top: 20px;
        }

        form {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<script>
    function openPDF(filename) {
        // You can use window.open to open the PDF in a new window or tab
        window.open('Uploaded/' + filename, '_blank');
        // If you want to open the PDF within the same page, you can use the embed or iframe tags
        // Uncomment the appropriate line based on your preference
        // document.body.innerHTML += '<embed src="dummy.pdf" type="application/pdf" width="100%" height="600px" />';
        // document.body.innerHTML += '<iframe src="dummy.pdf" width="100%" height="600px"></iframe>';
    }
</script>
<div class="container">
    <h1>Welcome back, <?php echo $username; ?></h1>
    <form action="logout.php" method="post">
        <button type="submit" class="btn btn-danger">Logout</button>
    </form>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
            <tr>
                <th>S.No.</th>
                <th>File Name</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $count = 1;
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $count . "</td>";
                    echo "<td>" . $row['filename'] . "</td>";
                    echo '<td>
                            <button onclick="openPDF(\'' . $row['filename'] . '\')">Open PDF</button>
                            <form method="post" style="display:inline;" onsubmit="return confirm(\'Are you sure you want to delete?\');">
                                <input type="hidden" name="delete" value="' . $row['filename'] . '">
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                          </td>';
                    echo "</tr>";
                    $count++;
                }
            } else {
                echo "<tr><td colspan='3'>No records found.</td></tr>";
            }
            ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
