<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
session_start();

if (!isset($_SESSION['uname'])) {
    header("location:/htdocs-OG/login/login.html");
    exit();
}

$conn=new mysqli('sql306.infinityfree.com','if0_35681883','MJN7pFUfAP','if0_35681883_users');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$uploadMessage = "";

if (isset($_POST['submit'])) {
    $targetDir = "Uploaded/";
    $targetFile = $targetDir . basename($_FILES["pdfFile"]["name"]);
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    if ($fileType != "pdf" || $_FILES["pdfFile"]["size"] > 2000000) {
        $uploadMessage = "Error: Only PDF files less than 2MB are allowed to upload.";
    } else {
        if (move_uploaded_file($_FILES["pdfFile"]["tmp_name"], $targetFile)) {
            $filename = $_FILES["pdfFile"]["name"];
            $folder_path = $targetDir;
            $time_stamp = date('Y-m-d H:i:s');
            $sql = "INSERT INTO files ( filename, folder_path, time_stamp)
                    VALUES ('$filename', '$folder_path', '$time_stamp')";
            if ($conn->query($sql) === TRUE) {
                $uploadMessage = "File uploaded successfully.";
                echo '<script>window.onload = function() {
                        alert("' . $uploadMessage . '");
                    }</script>';
            } else {
                $uploadMessage = "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            $uploadMessage = "Error uploading file.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>PDF Upload Form</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            height: 100vh;
            margin: 0;
        }

        .container {
            text-align: center;
        }

        table {
            margin-top: 20px;
        }

        form {
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Welcome back, <?php echo $_SESSION['uname']; ?></h1>
        <form action="logout.php" method="post">
            <button type="submit" class="btn btn-danger">Logout</button>
        </form>
        <div class="container d-flex justify-content-center align-items-center" style="height:60vh">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title text-center">Upload PDF File</h4>
                </div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="pdfFile">Select PDF File: </label>
                            <input type="file" name="pdfFile" class="form-control-file" id="pdfFile">
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary btn-block">Upload File</button>
                        <button type="reset" class="btn btn-warning btn-block">Reset</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>
