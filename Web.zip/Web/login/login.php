<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
    <link rel="icon" type="image/x-icon" href="img/favicon.ico">
       
</head>

<body>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
?>
    <div class="container" id="container">
        <div class="form-container sign-up">
            <form action="sconnect.php" method="post">
                <h1>Create Account</h1>
                <input type="text" placeholder="Username" name="Username">
                <input type="password" placeholder="Password" name="Password">
                <input type="password" placeholder="Enter your password again" name="CPassword">
                <input type="Secret code" placeholder="Secret code" name="Secret">
                <button>Sign Up</button>
            </form>
        </div>
        <div class="form-container sign-in">
            <form action="lconnect.php" method="post">
                <h1>Sign In</h1>
                <input type="text" placeholder="Username" name="Username">
                <input type="password" placeholder="Password" name="Password">
                <a href="#">Forget Your Password?</a>
                <button>Sign In</button>
            </form>
        </div>
        <div class="toggle-container">
            <div class="toggle">
                <div class="toggle-panel toggle-left">
                    <h1>Welcome Back!</h1>
                    <p>You can login with your existing credentials here</p>
                    <button class="hidden" id="login">Sign In</button>
                </div>
                <div class="toggle-panel toggle-right">
                    <h1>New here?</h1>
                    <p>You can sign up here<br>(Only if you have the secret code)</p>
                    <button class="hidden" id="register">Sign Up</button>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>

</html>