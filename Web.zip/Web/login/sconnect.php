<?php
$secret="";
$uname= $_POST['Username'];
$pass= $_POST['Password'];
$cpass= $_POST['CPassword'];
$secret= $_POST['Secret'];

$conn = new mysqli('sql306.infinityfree.com', 'if0_35681883', 'MJN7pFUfAP', 'if0_35681883_users');
if ($conn->connect_error)
{
    die('Connection failed : '.$conn->connect_error);
}
else if($secret!='abc123')
{
    header("location:secret\index.html");;
}
else if( $pass != $cpass)
{
    header("location:Password donot match\index.html");
}
else
{
    $stmt = $conn->prepare("Select * from userdata where UserName =? ");
    $stmt->bind_param("s", $uname);
    $stmt->execute();
    $res=$stmt->get_result();
    if($res->num_rows > 0)
    {
        header("location:UsernameTaken\index.html");
    }
    else
    {
    $stmt = $conn->prepare("insert into userdata(UserName,Pass)
    values(?,?)");
    $stmt->bind_param("ss", $uname,$pass);
    $stmt->execute();
    header("location:sdfe sf\index.html");
    $stmt->close();
    $conn->close();
    }
}
?>